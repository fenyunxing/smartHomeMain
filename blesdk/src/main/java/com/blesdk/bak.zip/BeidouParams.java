package com.blesdk;

public class BeidouParams {
    public static String SERVER_CARD_NUMBER = "306329";
    public static String SERVICE_UUID;
    public static boolean Debug = false;

    public static int boxVersion = 0;

    public static int getVersion = 0;

    public static boolean gattBluetoothAutoConnect = false;

    public static String bleaddress = null;

    public static boolean isboxUpdate = false;
}
